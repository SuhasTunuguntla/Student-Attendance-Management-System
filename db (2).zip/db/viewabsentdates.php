<!DOCTYPE html>
<?php
session_start();
?>

<?php

$studentrollno=$_SESSION['susername'];

$conn=mysql_connect("localhost","root","") or die("Could not connect!");
mysql_select_db("dbms") or die("Could not find db");
$courseid=$_POST['courseid'];
$cname=$_POST['cname'];

$result = mysql_query("SELECT * FROM absentdates WHERE studentrollno='$studentrollno' AND courseid='$courseid'");
if (mysql_num_rows($result) > 0) {
    // output data of each row
      echo $cname;
      echo "<br><br>";
    while($row = mysql_fetch_assoc($result)) {
        
        echo $row['absentdate'];
        echo "<br>";

        }
      

     

} else {
    echo "No absent dates";
}

?>
<br><br>
<a href="sattendance.php">Back to Page.  </a><br><br>

