

<!DOCTYPE html>

<html lang="en">
<head>
	<title>Admin Home</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/w3.css">
<!--===============================================================================================-->
</head>
<?php
    session_start();
?>
<?php
    $fusername=$_SESSION['fusername'];
    
    $conn=mysql_connect("localhost","root","") or die("Could not connect!");
    mysql_select_db("dbms") or die("Could not find db");
    
    
    $result = mysql_query("SELECT fid FROM faculty WHERE fusername='$fusername'");
    if (mysql_num_rows($result) > 0) {
        // output data of each row
        while($row = mysql_fetch_assoc($result)) {
            $fid=$row['fid'];
        }
    } else {
        echo "0 results";
    }
?>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100 p-t-30 p-b-50">
                <span class="login100-form-title p-b-41" style="font-size:40px">
					Your Courses
				</span>
				<form class="login100-form validate-form p-b-33 p-t-5">

<table border="3"; bordercolor="black" style="position:realtive; left:30px; color:black;" color:black; width=100% align="center" cellpadding="5" cellspacing="5">
                        <tr>
<th style="top:0px" padding:30px;> Course ID </th>
                            <th> Course Name</th>
                            
                        </tr>
                        <?php
                            
                            $query=mysql_query("SELECT * FROM course WHERE facultyid='$fid'");
                            if (mysql_num_rows($query) > 0) {
                                while($row = mysql_fetch_assoc($query)) {
                                ?>
                        <tr>
                            <td> <?php echo $row['cid']; ?> </td>
                            <td> <?php echo $row['cname']; ?> </td>
                        </tr>
                        <?php
                            
                            }
                            } else {
                                echo "0 results";
                            }
                        ?>
                    </table>
                    <?php
                        
                        mysql_close($conn);
                        ?>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
